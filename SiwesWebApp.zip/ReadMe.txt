>>>>>>>Read me file for SIWES app<<<<<<<<<

Admin Login Credentials
	>>>>Email: admin@siwes.com
	>>>>Password: 123456

Students Login Credentials
	The system automatically generates a default password for syudents registered in the platform
	>>>>All registered student's default password is 123456

Roles
	>>>>Admin
	>>>>Student
	>>>>Siwes Supervisor

Functionalities
	>>>>I.T letter printing
	>>>>Reply slip printing
	>>>>Logbook entry

Note: Logbook entrie is base on weekly activities.
	