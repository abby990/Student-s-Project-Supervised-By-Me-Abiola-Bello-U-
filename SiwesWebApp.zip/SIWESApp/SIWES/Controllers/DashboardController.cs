﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SIWES.Data;
using SIWES.Models.Schema;
using SIWES.Models.ViewModels;

namespace SIWES.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public DashboardController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [TempData]
        public string StatusMessage { get; set; }

        // GET: Dashboard
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Students()
        {
            var getstudents = await _context.Students.OrderBy(k=>k.RegNo).ToListAsync();
            return View(getstudents);
        }

        [HttpGet]
        public async Task<IActionResult> Student(string id = null)
        {
            var findstd = await _context.Students.FindAsync(id);

            var model = new NewStudentViewModel
            {
                Department = findstd?.Department,
                RegNo = findstd?.RegNo,
                LastName = findstd?.LastName,
                OtherNames = findstd?.OtherNames,
                Gender = findstd?.Gender,
                Id = findstd?.StudentId
            };

            if (id != null)
            {
                ViewBag.reference = "ok";
            }
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Student(NewStudentViewModel student, string id = null)
        {
            if (id != null)
            {
                ViewBag.reference = "ok";
            }

            if (ModelState.IsValid)
            {
                if (student.Id is null)
                {
                    if (string.IsNullOrWhiteSpace( student.Email))
                    {
                        ModelState.AddModelError(string.Empty, "Email required");
                        return View(student);
                    }

                    var checkreg = await _context.Students.AnyAsync(k => k.RegNo == student.RegNo.Trim().ToUpper());
                    if (checkreg)
                    {
                        ModelState.AddModelError(string.Empty, "Registration number exist already");
                        return View(student);
                    }

                    var newUser = new IdentityUser { Email = student.Email, UserName = student.Email, EmailConfirmed = true };
                    var result = await _userManager.CreateAsync(newUser, "123456");
                    if (result.Succeeded)
                    {
                        await _userManager.AddToRoleAsync(newUser, Helpers.EnumRoles.Student);
                        var newCandidate = new Student { Department = student.Department.ToUpper(), Gender = student.Gender.ToUpper(), LastName = student.LastName.ToUpper(), OtherNames = student.OtherNames.ToUpper(), RegNo = student.RegNo.ToUpper(), ProfileId = newUser.Id };

                        _context.Students.Add(newCandidate);
                        await _context.SaveChangesAsync();
                        return RedirectToAction(nameof(Students));
                    }
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }

                }
                else
                {
                    if (id != student.Id)
                    {
                        ModelState.AddModelError(string.Empty, "Invalid student reference");
                        return View(student);
                    }

                    var getstudent = await _context.Students.FindAsync(id);

                    getstudent.Department = student.Department.ToUpper();
                    getstudent.RegNo = student.RegNo.ToUpper();
                    getstudent.LastName = student.LastName.ToUpper();
                    getstudent.OtherNames = student.OtherNames.ToUpper();
                    getstudent.Gender = student.Gender.ToUpper();

                    _context.Students.Update(getstudent);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Students));
                }
            }
           

            return View(student);
        }

        [HttpGet]
        public async Task<IActionResult> Siwes()
        {
            var getsiwes = await _context.Students.Include(j=>j.Siwes).ThenInclude(h=>h.LogRecords).Where(d=>d.SiwesId != null).ToListAsync();
            return View(getsiwes);
        }

        [HttpGet]
        public async Task<IActionResult> SiwesInfo(string id = null)
        {
            var findstd = await _context.Students.Include(j=>j.Siwes).ThenInclude(y=>y.LogRecords).FirstOrDefaultAsync(t=>t.SiwesId == id);

            return View(findstd);
        }

        [HttpGet]
        public async Task<IActionResult> MySiwes()
        {
            var getuser = await _userManager.GetUserAsync(User);
            var getsiwes = await _context.Siwes.FirstOrDefaultAsync(h => h.ProfileId == getuser.Id);

            var model = new SiwesViewModel();
            if (getsiwes != null)
            {
                model.Mssg = StatusMessage;
                model.Company = getsiwes?.Company;
                model.Address = getsiwes?.Address;
                model.CoordinatorName = getsiwes?.CoordinatorName;
                model.Duration = getsiwes.Duration;
                model.EndDate = getsiwes.EndDate;
                model.Phone = getsiwes?.Phone;
                model.StartDate = getsiwes.StartDate;
                model.CoordinatorPhone = getsiwes?.CoordinatorPhone;
            }

            return View(model);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MySiwes(SiwesViewModel siwes)
        {
            var getuser = await _userManager.GetUserAsync(User);
            if (ModelState.IsValid)
            {
                var getstd = await _context.Students.FirstOrDefaultAsync(h => h.ProfileId == getuser.Id);
                var getsiwes = await _context.Siwes.FirstOrDefaultAsync(h => h.ProfileId == getuser.Id);
                if (getsiwes == null)
                {
                    var newSiwes = new Siwes { ProfileId = getuser.Id, Address = siwes.Address.ToUpper(), Company = siwes.Company.ToUpper(), CoordinatorName = siwes.CoordinatorName.ToUpper(), CoordinatorPhone = siwes.CoordinatorPhone, Phone = siwes.Phone, StartDate = DateTime.Now.ToShortDateString(), EndDate = DateTime.Now.AddMonths(3).ToShortDateString() };

                    TimeSpan difference = DateTime.Now.AddMonths(3) - DateTime.Now;
                    var diffInDays = difference.TotalDays;
                    var diffInWeeks =(int)diffInDays / 7;
                    newSiwes.Duration = (int)diffInWeeks;

                    for (int i = 0; i < diffInWeeks; i++)
                    {
                        var createLog = new LogEntry { SiwesId = newSiwes.SiwesId, ProfileId = getuser.Id , Week = i};
                        await _context.LogEntries.AddAsync(createLog);
                    }

                    getstd.SiwesId = newSiwes.SiwesId;

                    _context.Students.Update(getstd);
                    await _context.Siwes.AddAsync(newSiwes);
                    await _context.SaveChangesAsync();

                    StatusMessage = "Siwes was registered successfully";
                    return RedirectToAction(nameof(MySiwes));
                }
                else
                {
                    getsiwes.Address = siwes.Address.ToUpper();
                    getsiwes.Company = siwes.Company.ToUpper();
                    getsiwes.CoordinatorName = siwes.CoordinatorName.ToUpper();
                    getsiwes.CoordinatorPhone = siwes.CoordinatorPhone;
                    getsiwes.Phone = siwes.Phone;

                    _context.Siwes.Update(getsiwes);
                    await _context.SaveChangesAsync();

                    StatusMessage = "Siwes was updated successfully";
                    return RedirectToAction(nameof(MySiwes));
                }
            }

            ModelState.AddModelError(string.Empty, "Error occured!");
            return View(siwes);
        }

        [HttpGet]
        public async Task<IActionResult> MyLogbook()
        {
            var getuser = await _userManager.GetUserAsync(User);
            var getsiwes = await _context.LogEntries.Where(h => h.ProfileId == getuser.Id && h.IsFilled == true).ToListAsync();

            return View(getsiwes);
        }


        [HttpGet]
        public async Task<IActionResult> Logbook(int week)
        {
            var getuser = await _userManager.GetUserAsync(User);
            var getsiwes = await _context.LogEntries.FirstOrDefaultAsync(h => h.ProfileId == getuser.Id && h.Week == week);

            ViewBag.week = week;
            return View(getsiwes);
        }

          [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logbook(int week, LogEntry entry)
        {
            var getuser = await _userManager.GetUserAsync(User);
            var getsiwes = await _context.LogEntries.FirstOrDefaultAsync(h => h.ProfileId == getuser.Id && h.Week == entry.Week);
            var gets = await _context.Siwes.FirstOrDefaultAsync(e => e.ProfileId == getuser.Id);

            if (getsiwes == null)
            {
                ModelState.AddModelError(string.Empty, $"Your Logbook does not include week {week}");
                return View(entry);
            }

            if (gets == null)
            {
                ModelState.AddModelError(string.Empty, $"Your valid Siwes was found");
                return View(entry);
            }

            TimeSpan difference = DateTime.Now - Convert.ToDateTime(gets.StartDate);
            var diffInDays = difference.TotalDays;
            var diffInWeeks = (int)diffInDays / 7;

            if (diffInWeeks < entry.Week)
            {
                ModelState.AddModelError(string.Empty, $"Please wait till week {week} is complete before filling this log");
                return View(entry);
            }


            if (ModelState.IsValid)
            {
                getsiwes.LogTitle = entry.LogTitle;
                getsiwes.Description = entry.Description;
                getsiwes.Comment = entry.Comment;
                getsiwes.IsFilled = true;
                getsiwes.EntryDate = DateTime.Now;

                _context.LogEntries.Update(getsiwes);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(MyLogbook));
            }

            ModelState.AddModelError(string.Empty, "Errors occured");
            return View(entry);
        }

        [HttpGet]
        public async Task<IActionResult> PrintLetter()
        {
            var getuser = await _userManager.GetUserAsync(User);
            var getsiwes = await _context.Students.FirstOrDefaultAsync(h => h.ProfileId == getuser.Id);

            return View(getsiwes);
        }

          [HttpGet]
        public IActionResult PrintSlip()
        {
           
            return View();
        }



















































        // GET: Dashboard/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var student = await _context.Students
                .Include(s => s.Siwes)
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }

        // GET: Dashboard/Create
        public IActionResult Create()
        {
            ViewData["SiwesId"] = new SelectList(_context.Siwes, "SiwesId", "SiwesId");
            return View();
        }

        // POST: Dashboard/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StudentId,RegNo,LastName,OtherNames,Gender,Department,SiwesId")] Student student)
        {
            if (ModelState.IsValid)
            {
                _context.Add(student);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["SiwesId"] = new SelectList(_context.Siwes, "SiwesId", "SiwesId", student.SiwesId);
            return View(student);
        }

        // GET: Dashboard/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var student = await _context.Students.FindAsync(id);
            if (student == null)
            {
                return NotFound();
            }
            ViewData["SiwesId"] = new SelectList(_context.Siwes, "SiwesId", "SiwesId", student.SiwesId);
            return View(student);
        }

        // POST: Dashboard/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("StudentId,RegNo,LastName,OtherNames,Gender,Department,SiwesId")] Student student)
        {
            if (id != student.StudentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(student);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StudentExists(student.StudentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["SiwesId"] = new SelectList(_context.Siwes, "SiwesId", "SiwesId", student.SiwesId);
            return View(student);
        }

        // GET: Dashboard/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var student = await _context.Students
                .Include(s => s.Siwes)
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }

        // POST: Dashboard/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var student = await _context.Students.FindAsync(id);
            _context.Students.Remove(student);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StudentExists(string id)
        {
            return _context.Students.Any(e => e.StudentId == id);
        }
    }
}
