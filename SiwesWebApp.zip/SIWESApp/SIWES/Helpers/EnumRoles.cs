﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SIWES.Helpers

{
    public static class EnumRoles
    {
        public static string SuperAdmin { get; set; } = "Admin";
        public static string Student { get; set; } = "Student";
        public static string Supervisor { get; set; } = "Supervisor";

    }
}
