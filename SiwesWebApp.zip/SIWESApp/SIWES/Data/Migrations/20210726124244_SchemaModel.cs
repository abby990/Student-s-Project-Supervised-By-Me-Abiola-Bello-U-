﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SIWES.Data.Migrations
{
    public partial class SchemaModel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Siwes",
                columns: table => new
                {
                    SiwesId = table.Column<string>(nullable: false),
                    Company = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true),
                    CoordinatorName = table.Column<string>(nullable: true),
                    Duration = table.Column<int>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Siwes", x => x.SiwesId);
                });

            migrationBuilder.CreateTable(
                name: "LogEntries",
                columns: table => new
                {
                    LogId = table.Column<string>(nullable: false),
                    EntryDate = table.Column<DateTime>(nullable: false),
                    LogTitle = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    Diagram = table.Column<byte[]>(nullable: true),
                    SiwesId = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LogEntries", x => x.LogId);
                    table.ForeignKey(
                        name: "FK_LogEntries_Siwes_SiwesId",
                        column: x => x.SiwesId,
                        principalTable: "Siwes",
                        principalColumn: "SiwesId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentId = table.Column<string>(nullable: false),
                    RegNo = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    OtherNames = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: true),
                    Department = table.Column<string>(nullable: true),
                    SiwesId = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.StudentId);
                    table.ForeignKey(
                        name: "FK_Students_Siwes_SiwesId",
                        column: x => x.SiwesId,
                        principalTable: "Siwes",
                        principalColumn: "SiwesId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LogEntries_SiwesId",
                table: "LogEntries",
                column: "SiwesId");

            migrationBuilder.CreateIndex(
                name: "IX_Students_SiwesId",
                table: "Students",
                column: "SiwesId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LogEntries");

            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Siwes");
        }
    }
}
