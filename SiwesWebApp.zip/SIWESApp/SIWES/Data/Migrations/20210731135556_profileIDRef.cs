﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SIWES.Data.Migrations
{
    public partial class profileIDRef : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ProfileId",
                table: "Students",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProfileId",
                table: "Siwes",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProfileId",
                table: "LogEntries",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProfileId",
                table: "Students");

            migrationBuilder.DropColumn(
                name: "ProfileId",
                table: "Siwes");

            migrationBuilder.DropColumn(
                name: "ProfileId",
                table: "LogEntries");
        }
    }
}
