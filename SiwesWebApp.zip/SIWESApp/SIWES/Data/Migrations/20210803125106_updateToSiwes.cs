﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SIWES.Data.Migrations
{
    public partial class updateToSiwes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CoordinatorPhone",
                table: "Siwes",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Week",
                table: "LogEntries",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CoordinatorPhone",
                table: "Siwes");

            migrationBuilder.DropColumn(
                name: "Week",
                table: "LogEntries");
        }
    }
}
