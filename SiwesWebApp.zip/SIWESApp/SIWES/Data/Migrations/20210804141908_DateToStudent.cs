﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SIWES.Data.Migrations
{
    public partial class DateToStudent : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "RegDate",
                table: "Students",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RegDate",
                table: "Students");
        }
    }
}
