﻿using SIWES.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SIWES.Models.Schema;

namespace SIWES.Data
{
    public class ApplicationDbInitializer
    {
        public static async Task InitializeIdentity(ApplicationDbContext db, RoleManager<IdentityRole> roleManager, UserManager<IdentityUser> userManager)
        {
            db.Database.EnsureCreated();

            var superuser = userManager.Users.Any(t => t.UserName == "admin@siwes.com");
            if (!superuser)
            {
                var user = new IdentityUser { UserName = "admin@siwes.com", Email = "admin@siwes.com", EmailConfirmed = true };

                await userManager.CreateAsync(user, "123456");

                var role = await roleManager.FindByNameAsync(Helpers.EnumRoles.SuperAdmin);
                if (role == null)
                {
                    string[] roles = { Helpers.EnumRoles.SuperAdmin, Helpers.EnumRoles.Student, Helpers.EnumRoles.Supervisor };

                    foreach (var rname in roles)
                    {
                        var rolename = await roleManager.RoleExistsAsync(rname);
                        if (!rolename)
                        {
                            role = new IdentityRole(rname);
                            await roleManager.CreateAsync(role);
                        }
                    }
                }
               
                await userManager.AddToRoleAsync(user, Helpers.EnumRoles.SuperAdmin);
                await db.SaveChangesAsync();
            }
        }

    }
}