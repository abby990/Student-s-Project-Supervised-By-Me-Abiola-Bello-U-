﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SIWES.Models.Schema;
using System;
using System.Collections.Generic;
using System.Text;

namespace SIWES.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Student> Students { get; set; }
        public virtual DbSet<Siwes> Siwes { get; set; }
        public virtual DbSet<LogEntry> LogEntries { get; set; }
    }
}
