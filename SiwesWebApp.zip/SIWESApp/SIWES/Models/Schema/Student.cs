﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SIWES.Models.Schema
{
    public class Student
    {
        public Student()
        {
            StudentId = Guid.NewGuid().ToString();
            RegDate = DateTime.Today.ToLongDateString();
        }
       
        public string StudentId { get; set; }
        public string RegNo { get; set; }
        public string LastName { get; set; }
        public string OtherNames { get; set; }
        public string Gender { get; set; }
        public string Department { get; set; }
        public string RegDate { get; set; }


        public string SiwesId { get; set; }
        public virtual Siwes Siwes { get; set; }
        public string ProfileId { get; set; }
    }
}

