﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SIWES.Models.Schema
{
    public class LogEntry
    {
        public LogEntry()
        {
            LogId = Guid.NewGuid().ToString();
        }

        [Key]
        public string LogId { get; set; }
        public DateTime EntryDate { get; set; }
        public string LogTitle { get; set; }
        public string Description { get; set; }
        public string Comment { get; set; }
        public byte[] Diagram { get; set; }
        public int Week { get; set; }

        public string SiwesId { get; set; }
        public virtual Siwes Siwes { get; set; }

        public string ProfileId { get; set; }
        public bool IsFilled { get; set; }

    }
}
