﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SIWES.Models.Schema
{
    public class Siwes
    {
        public Siwes()
        {
            SiwesId = Guid.NewGuid().ToString();
        }
        public string SiwesId { get; set; }
       
        public string Company { get; set; }
      
        public string Address { get; set; }
     
        public string Phone { get; set; }
     
        public string CoordinatorName { get; set; } 
     
        public string CoordinatorPhone { get; set; }

        public int Duration { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ProfileId { get; set; }

        public virtual ICollection<LogEntry> LogRecords { get; set; }

    }
}
