﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SIWES.Models.ViewModels
{
    public class NewStudentViewModel
    {
        [Required(ErrorMessage ="Registration no. required")]
        public string RegNo { get; set; }
        public string Id { get; set; }
        [Required(ErrorMessage = "Last name required")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Other Names required")]
        public string OtherNames { get; set; }
        [Required(ErrorMessage = "Gender required")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "Department required")]
        public string Department { get; set; } 
      
        [EmailAddress]
        public string Email { get; set; }
    }
}
