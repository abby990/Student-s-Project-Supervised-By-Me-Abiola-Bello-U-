﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SIWES.Models.ViewModels
{
    public class SiwesViewModel
    {
        [Required(ErrorMessage = "Company name required")]
        public string Company { get; set; }
        [Required(ErrorMessage = "Company address required")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Company phone number required")]
        public string Phone { get; set; }
        [Required(ErrorMessage = "Company supervisor required")]
        public string CoordinatorName { get; set; }
        [Required(ErrorMessage = "Company supervisor mobile required")]
        public string CoordinatorPhone { get; set; }
        public int Duration { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Mssg { get; set; }

    }
}
