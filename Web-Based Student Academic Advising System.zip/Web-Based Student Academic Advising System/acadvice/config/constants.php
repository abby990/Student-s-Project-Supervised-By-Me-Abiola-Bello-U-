<?php 

	define("SERVER","localhost");
	define("DATABASE","career");
	define("USERNAME","root");
	define("PASSWORD","");
	


?>