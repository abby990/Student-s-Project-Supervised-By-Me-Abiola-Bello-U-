	$.ajaxSetup({
		return false
	});