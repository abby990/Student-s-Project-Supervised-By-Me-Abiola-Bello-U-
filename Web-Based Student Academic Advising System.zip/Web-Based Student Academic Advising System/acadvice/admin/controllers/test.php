<?php

class test {
	
	function test($a = null, $b = null)
	{
		echo "Ajax View... $a $b";
	}
}