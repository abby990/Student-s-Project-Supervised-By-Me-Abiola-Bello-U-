<?php

class cache {
	
	public $cache;
	
	function add()
	{
		
	}
	
	function delete()
	{
		
	}
}