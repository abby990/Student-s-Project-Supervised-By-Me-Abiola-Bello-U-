/**
 * Basic Plugin Example
 * 
 * basic.js
 */

//this is a very basic plugin demonstrating how to pass data accross.
//look inside info.php for more comments and usage.
function basic(a, b, c)
{
	alert(this.test);
	
}