<?php

define('AJAX_INCLUDES', true);
/**
 * Here you may include any dependencies that you may need for authentication 
 * or others files or dependencies you may need.
 */

## Your includes go here.
//eg. require_once 'your/file.php';
