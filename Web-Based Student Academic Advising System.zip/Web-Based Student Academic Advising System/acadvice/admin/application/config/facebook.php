<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '165792323766003';
$config['secret']  = '29fe9290889fc372b1e1304f7bbb1b5e';

?>
