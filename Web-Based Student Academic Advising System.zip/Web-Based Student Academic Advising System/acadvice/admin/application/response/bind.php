<?php

class controller_bind  {
	
	function link1()
	{
		
	}
	
	function link2()
	{
		
	}
	
	function bind_elements()
	{
		$ajax = CJAX::getInstance();
		
		$ajax->info("same command..");
		
	}
}