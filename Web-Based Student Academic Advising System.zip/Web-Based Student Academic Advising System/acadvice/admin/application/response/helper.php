<?php

class helper {
	
	function api()
	{
		echo 'success';
	}
}