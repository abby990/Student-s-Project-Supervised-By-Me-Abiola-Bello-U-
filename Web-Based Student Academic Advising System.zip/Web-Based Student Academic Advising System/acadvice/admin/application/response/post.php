<?php

class post {
	
	
	function post_sample()
	{
		echo 'Response is<pre>'.print_r($_POST,1).'</pre>';
	}
}