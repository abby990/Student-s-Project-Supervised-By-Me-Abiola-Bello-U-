<?php

class validation_uploader  {
	
	function pre()
	{
		die('pre!');
	}
	
	function post()
	{
		die('post!');
	}
}