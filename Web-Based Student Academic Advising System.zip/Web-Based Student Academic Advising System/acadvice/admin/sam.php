<?php
echo $_POST['first'];
?>